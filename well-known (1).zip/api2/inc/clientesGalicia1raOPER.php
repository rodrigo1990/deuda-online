
<div class="col-sm-12"><span class="hf_tabla"><?php  echo $response->nombre; ?></span></div>

<div class="col-sm-12 text-center" style="font-size: 16px; color:#404041; margin-bottom: 20px;">
        <h4><b>Tenemos un descuento especial para vos por tu deuda con BANCO GALICIA, <br> dejanos tus datos para mayor información:</b></h4>
        <img src="../imagenes/logos_pagos/galicia-big.png" alt="Banco Galicia" class="center-block" width="169">
</div>


<?php include("formularioDeContactoDePago.php") ?>