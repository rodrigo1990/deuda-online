function mostrarAyudaModal(){
	$("#ayuda-xs-modal").modal('show');
}