
  
  <body>
    <header>
      <div class="container">
        <div class="col-sm-4 text_center_mobile">
          <a href="index.php" class="logo"><img src="imagenes/logo.png" alt="Deuda Online" id="logo" /></a>
        </div>
        <div class="col-sm-8">
          <div id="cssmenu" style="position: relative; z-index:999;">
            <ul>
               <li class=""><a href="deuda_online.php">QUE ES DEUDA ONLINE</a></li>
               <li class=""><a href="preguntas_frecuentes.php">PREGUNTAS FRECUENTES</a></li>
               <li class=""><a href="quiero_pagar.php">QUIERO PAGAR</a></li>
               <li class=""><a href="contacto.php">CONTACTO</a></li>
            </ul>
          </div>
        </div>
        <div class="clear"></div>
      </div>
    </header>
<div class="clear"></div>