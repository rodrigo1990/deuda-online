<?php include('head.php'); ?>
<?php include('header.php'); ?>

<img src="imagenes/deuda_online/cabecera.jpg" alt="" class="img_full" /><br /><br /><br /><br /><br />

<div class="container">
  <div class="col-sm-10 col-sm-offset-1 text-center">
    <h1 class="titulos">DEUDA ONLINE</h1><br />
    <p class="textos text-center">
      Con Deuda Online obtenés los mejores planes de pago y podés deshacerte de tus deudas de manera fácil, rápida y transparente. Nuestros clientes son bancos, empresas de servicios, compañías de seguros, entre otros. Nos contratan con el fin de que te ofrezcamos la mejor alternativa para cancelar tu deuda.
      <br /><br />
      <b>Contactate con nuestros especialistas que escucharán tu situación personal y te ayudarán con el pago.</b>
    </p>
    <br /><br /><br />
  </div>
</div>

<?php include('footer.php'); ?>