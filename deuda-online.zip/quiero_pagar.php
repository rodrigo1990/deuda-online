<?php include('head.php'); ?>
<div class="main">
<?php include('header.php'); ?>

<div class="cabecera_160" id="c_quiero_pagar">
   BUSCAR DEUDAS A MI NOMBRE
</div>
<br /><br />

<div class="container">
  <iframe src="api2/"></iframe>
</div>

 <div class="callBkground" >
		      <a id="click2call_hupbtn" class="pointer">
		            <img src="https://webrtc.anura.com.ar/click2call/img/phone_hang.png" class="picar">
		      </a>

		  </div>
 

    
 <?php include("inc/contactoWspAnura.php") ?>       
 <?php include('ayuda-xs.php'); ?>
 <script src="js/mostrarAyudaModal.js"></script>
</div>
<?php include('footer.php'); ?>