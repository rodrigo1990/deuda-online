 <div id = "ayuda-xs-modal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content center-block">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <img src="imagenes/quiero_pagar/pasoApasoxs1.jpg" class="paso-a-paso-xs center-block" alt="">
       <img src="imagenes/quiero_pagar/pasoApasoxs2.jpg" class="paso-a-paso-xs center-block" alt="">
       <img src="imagenes/quiero_pagar/pasoApasoxs3.jpg" class="paso-a-paso-xs center-block" alt="">
       <img src="imagenes/quiero_pagar/pasoApasoxs4.jpg" class="paso-a-paso-xs center-block" alt="">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">¡ENTENDIDO!</button>
      </div>
    </div>
  </div>
</div>


<a class="ayuda-xs-btn" onClick="mostrarAyudaModal()">
	<h2><b>?</b></h2>
</a>