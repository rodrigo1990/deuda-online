<?php
$classFile = 'BCGisbn.barcode.php';
$className = 'BCGisbn';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '5.2.0';
?>