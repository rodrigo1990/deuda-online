<?php
header('Location: BCGi25.php?ac='.$_GET['ac'].'&dni='.$_GET['dni']);
?>