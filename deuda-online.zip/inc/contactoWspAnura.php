
   <div class="container">
		         <span style="font-size:14px;text-align: left !important">
		          <p class="p-footer">
		            Ante cualquier duda consultá a un referente de Deuda Online al teléfono <a id="click2call_callbtn" class="pointer green a-footer"><i class="fas fa-phone"></i> <b>011 7078-8512</a></b>
		          </p>
		          <p class="p-footer">
		            O envianos un WhatsApp a <a href="https://api.whatsapp.com/send?phone=541126531118&text=¡Hola!%20Queria%20hacer%20una%20consulta%20acerca%20de%20los%20servicios%20brindados%20en%20www.deudaonline.com.ar"target="_blank" class="green a-footer"><i class="fab fa-whatsapp fa-lg"></i> <b>+54 9 11 2653 1118</b></a>
		          </p>
		        </span>      
        </div>
           <div id="click2call" align="center">
          
          
           
          
          <div id="click2call_msgdiv"></div>
           
          <div style="visibility: hidden; display: none;">
            <input id="click2call_user" value="982">
            <input id="click2call_domain" value="argen.grancentral.com.ar">
            <input id="click2call_password" value="982@2e05">
            <input id="click2call_number" value="500">
            <input id="click2call_host" value="wss://webrtc.anura.com.ar:9084">
          </div>
           
          <div id="media" style="visibility: hidden; display: none;">
            <video width=800 id="webcam" autoplay="autoplay" hidden="true"></video>
          </div>
        </div>
