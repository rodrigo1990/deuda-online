
<footer></footer>
<script src="https://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="https://s3.amazonaws.com/menumaker/menumaker.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/menu.js"></script>
    <script src="js/manejoDeClasesEnHeaderSegunLaPaginaCargada.js"></script>
    <!-- Código de instalación Cliengo para  www.deudaonline.com.ar/index/ -->
    <script type="text/javascript">(function(){var ldk=document.createElement('script');ldk.type='text/javascript';ldk.async=true;ldk.src='https://s.cliengo.com/weboptimizer/5ab2de19e4b0b795c557873c/5ac3e72be4b09ccb2aaa44a5.js';var s=document.getElementsByTagName('script')[0];s.parentNode.insertBefore(ldk, s);})();</script>

		<script type="text/javascript" src="js/mailCantidadCuotas.js"></script>
		<script type="text/javascript" 
		    src="https://webrtc.anura.com.ar/click2call/js/jquery.json-2.4.min.js">
		</script>
		<script type="text/javascript" 
		    src="https://webrtc.anura.com.ar/click2call/js/jquery.cookie.js">
		</script>
		<script type="text/javascript" 
		    src="js/verto-min.js">
		</script>
		<script type="text/javascript" 
		    src="js/click2call.js">
		</script>