<?php include('header.php'); ?>

<div class="cabecera_300" id="c_derechos">
  <div class="container">
   TUS DERECHOS
  </div>
</div>

<div class="container">

  <div class="col-sm-12">
    <b>Tenés derecho a:</b>
    <br /><br />
    - Exigir el detalle de la deuda, su composición y la forma concreta de cancelación.
    <br /><br />
    - A obtener un recibo de pago por cada pago que realices con el detalle de los conceptos que estás abonando (por ejemplo: cuota 1 de 12, etc).
    <br /><br />
    - Al finalizar la deuda, exigir un recibo cancelatorio que detalle toda la información de la deuda abonada 
    <br /><br />
    - Que se te brinde asesoramiento profesional, justo y bien claro.
    <br /><br />
    - A ser representado por un tercero, profesional o no.
    <br /><br />
    - Deuda Online es un servicio de EPB&A y cumple con el Art. 8 bis de la ley de Defensa del Consumidor.
    <br /><br />
  <div>

</div>


<?php include('footer.php'); ?>