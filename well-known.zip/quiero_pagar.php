<?php include('header.php'); ?>

<div class="cabecera_160" id="c_quiero_pagar">
   BUSCAR DEUDAS A MI NOMBRE
</div>
<br /><br />

<div class="container">
  <iframe src="https://www.deudaonline.com.ar/api2/" style="width: 100%; height: 640px; border: 0px; overflow: hidden;"></iframe>
</div>

<?php include('footer.php'); ?>