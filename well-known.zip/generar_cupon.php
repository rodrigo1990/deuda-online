<?php
header('Location: html/index.php?ac='.$_GET['ac'].'&dni='.$_GET['dni']);
?>