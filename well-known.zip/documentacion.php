<?php include('header.php'); ?>

<div class="cabecera_300" id="c_documentacion">
  <div class="container">
   DOCUMENTACIÓN
  </div>
</div>

<div class="container">

  <div class="col-sm-12">
    <div class="text-center" style="font-size: 15px;"><b>¿QUÉ COMPROBANTES DE PAGO OBTENÉS AL SUSCRIBIR UN PLAN DE PAGOS?</b></div>
    <br /><br /><br />
    <b>Deuda Online emitirá dos tipos de comprobantes:</b><br /><br />
    El recibo por cuenta y orden de nuestro mandante (tu acreedor), correspondiente a cada cuota que abones. La carta de cancelación total, al finalizar el plan de pagos o realizada la cancelación en un único pago.<br /><br />
    Estos comprobantes contienen toda la información necesaria, la fecha y monto, la deuda que estas pagando y/o cancelando, tus datos personales, el nombre del acreedor, etc.
  </div>

</div>


<?php include('footer.php'); ?>