<?php
	
	function httpConsultarDocumento($url, $user, $pwd, $documento = '', $telefono = '', $mail = '', $culture = '') {
		$debug  	= true;
		$useCurl	= false;
	
		if($debug) {
			error_reporting(E_ALL);
		}
		
		
		$fields = array();
		$fields['op'] 	= 'info';
		$fields['doc'] 	= $documento;
		$fields['user']	= $user;
		$fields['pwd']	= $pwd;
		
		if($telefono) {
			$fields['tel'] 	= $telefono;
		}
		
		if($mail) {
			$fields['mail'] 	= $mail;
		}
		
		if($culture) {
			$fields['culture'] 	= $culture;
		}

		
		$fields_string = http_build_query ($fields);

		if($useCurl) {
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HEADER,			false);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION,	true);
			curl_setopt($ch, CURLOPT_MAXREDIRS,		10);
			curl_setopt($ch, CURLOPT_ENCODING,		'');
			curl_setopt($ch, CURLOPT_USERAGENT,		'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36');
			curl_setopt($ch, CURLOPT_AUTOREFERER,	true);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,	120);
			curl_setopt($ch, CURLOPT_TIMEOUT,		120);
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_POST, count($fields));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
			$result = curl_exec($ch);
			curl_close($ch);

		} else {
			
			$contextData = array ( 
				'method' => 'POST',
				'header' => "Content-type: application/x-www-form-urlencoded\r\n" . "Connection: close\r\n".
				"Content-Length: ".strlen($fields_string)."\r\n",
				'content'=> $fields_string );

			$context = stream_context_create (array ( 'http' => $contextData ));
			
			$result =  file_get_contents (
				$url,  
				false,
				$context);

		}
		

		$response =  new StdClass();
		
		if(!$result) {
			$response->status = 'ERROR DE COMUNICACION'; 
			return $response;
		}
		$dom = new \DomDocument();
		$loadXML = @$dom->loadXML($result);
		
		if(!$loadXML) {
			$response->status = 'ERROR NO ES UN XML';
			if($debug) {
				$response->status .= ' (' . $result . ')';
			}
			return $response;
		}

		$response->status = 'OK';
			

		$simplexml 	= simplexml_import_dom($dom);
		$response->queryStart 	= isset($simplexml->QueryStart) ? trim(strval($simplexml->QueryStart)) : '';
		$response->queryType 	= isset($simplexml->QueryType) ? trim(strval($simplexml->QueryType)) : '';
		$response->queryEnd 	= isset($simplexml->QueryEnd) ? trim(strval($simplexml->QueryEnd)) : '';
		
			
		$response->nombre 		= isset($simplexml->Resultado->nombre) ? trim(strval($simplexml->Resultado->nombre)) : '';
		$response->cantProd		= isset($simplexml->Resultado->cant_prod) ? trim(strval($simplexml->Resultado->cant_prod)) : '';
		$response->saldoTotal 	= isset($simplexml->Resultado->SaldoTotal) ? trim(strval($simplexml->Resultado->SaldoTotal)) : '';
			
			
		$response->productos = array();
		$max = isset($simplexml->Resultado->Productos->pr) ? count($simplexml->Resultado->Productos->pr) : 0;
			
		for($i = 0; $i < $max; $i++) {
			$producto =  new StdClass();
			$producto->nombre  	= isset($simplexml->Resultado->Productos->pr[$i]->nombre) ? trim(strval($simplexml->Resultado->Productos->pr[$i]->nombre)) : '';
			$producto->acreedor = isset($simplexml->Resultado->Productos->pr[$i]->acreedor) ? trim(strval($simplexml->Resultado->Productos->pr[$i]->acreedor)) : '';
			$producto->moneda 	= isset($simplexml->Resultado->Productos->pr[$i]->moneda) ? trim(strval($simplexml->Resultado->Productos->pr[$i]->moneda)) : '';
			$producto->saldo 	= isset($simplexml->Resultado->Productos->pr[$i]->saldo) ? trim(strval($simplexml->Resultado->Productos->pr[$i]->saldo)) : '';
			
			$response->productos[$i] = $producto;
		}
		
		return $response;
	}
			


