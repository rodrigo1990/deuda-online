<?php header('Content-Type: text/html; charset=utf-8'); ?>
<?php
	include 'inc_consultar_datos.php';
	$url	= 'http://190.111.231.172:8099';
	$user	= 'lcreativa';
	$pwd	= 'p4lm3r0_2016';
	

	$response = null;
	if($_SERVER['REQUEST_METHOD'] == 'POST') {
		$documento 	= isset($_POST['documento']) ? htmlentities(trim(strval($_POST['documento']))) : '';
		$telefono 	= isset($_POST['telefono']) ? htmlentities(trim(strval($_POST['telefono']))) : '';
		$mail 		= isset($_POST['mail']) ? htmlentities(trim(strval($_POST['mail']))) : '';
		$culture 	= isset($_POST['culture']) ? htmlentities(trim(strval($_POST['culture']))) : '';
		if($documento) {
			$response 	= httpConsultarDocumento($url, $user, $pwd, $documento, $telefono, $mail, $culture);
		}
	}
	
	/*
	$documentoUsuario 	= '10061484';
	
	print_r($response);*/
?>

<style type="text/css">
body
{
  font-family: 'Open Sans', sans-serif;
  font-size: 13px;
  color: #6d6e70;
  background: #ffffff;
}

.contactorapido_btn
{
  margin-top: 20px;
  background: #1a9cd6;
  color: #ffffff;
  border: 0px;
  padding: 5px 15px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
}

a:hover
{
  text-decoration: none;
  color: #ffffff;
}
</style>
<html>
	<head>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <title>Deuda Online</title>
	    <meta name="Keywords" content="">
	    <meta name="Description" content=""/>

		<link href="css/bootstrap.min.css" rel="stylesheet">
	    
	    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
	    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,700" rel="stylesheet">
	</head>
	<body style="text-align:center;">
		<?php
		if($_SERVER['REQUEST_METHOD'] != 'POST') { ?>
		<div class="col-sm-12 text-center" style="font-size: 16px; color:#404041; margin-bottom: 20px;"><b>Ingrese su número de DNI<br />para conocer el saldo de su deuda</b></div>

		<form action="index.php" method="post">
			<input type="text" name="documento" required style="border: 0px; border-bottom: 3px solid #1a9cd6; width: 100%; max-width: 480px;" /><br />
			<!-- <input type="text" name="telefono" placeholder="Telefono" value="" /> -->
			<!-- <input type="text" name="mail" placeholder="Email" value="" /> -->
			<!-- <input type="text" name="culture" placeholder="Culture" value=""  /> -->
			<input type="submit" name="submit" value="ACEPTAR" class="contactorapido_btn" />
		</form>
		<?php } ?>
		
		<?php
			if($response && $response->status != 'OK') {
				// echo '<h1 style="color: red">'.$response->status.'</h1>';
			}
			if($response && $response->status == 'OK') :		?>
				<div class="col-sm-12 text-center" style="font-size: 16px; color:#404041; margin-bottom: 20px;"><b>El detalle de su deuda<br />al día de la fecha es el siguiente:</b></div>
				
				<table style="width: 100%; max-width: 700px; margin: auto; font-weight: 400;  text-align:center;">
					<thead style="border-bottom: 1px solid #1a9cd6; height: 50px;">
						<tr>
							<th style="color: #1a9cd6; text-align:center; padding-bottom: 5px; text-transform: uppercase; font-size: 13px;">Producto</th>
							<th style="color: #1a9cd6; text-align:center; padding-bottom: 5px; text-transform: uppercase; font-size: 13px;">Acreedor</th>
							<th style="color: #1a9cd6; text-align:center; padding-bottom: 5px; text-transform: uppercase; font-size: 13px;">USTED DEBE</th>
							<th style="color: #1a9cd6; text-align:center; padding-bottom: 5px; text-transform: uppercase; font-size: 13px;">Cancela</th>
							<th style="color: #1a9cd6; text-align:center; padding-bottom: 5px; text-transform: uppercase; font-size: 13px;">Nctas1</th>
							<th style="color: #1a9cd6; text-align:center; padding-bottom: 5px; text-transform: uppercase; font-size: 13px;">Mcta1</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($response->productos as $producto) :  ?>
							<?php 
								$fecha_deuda = $producto->fmora;
								$fecha_deuda = substr($fecha_deuda, 0, 10);

								$dia_deuda = substr($fecha_deuda, 0, 2);
								$mes_deuda = substr($fecha_deuda, 3, 2);
								$anio_deuda = substr($fecha_deuda, 6, 4);

								$fecha_rev = $anio_deuda . '-' . $mes_deuda . '-' . $dia_deuda;

								$now = time();
								$your_date = strtotime($fecha_rev);
								$datediff = $now - $your_date;
								$cant_dias = floor($datediff / (60 * 60 * 24));

								$saldo = $producto->saldo;

								$mora = ($cant_dias * 9)/100;
								$adicional = ($saldo * $mora)/100;

								$total = round($saldo + $adicional);

								$cuota_1 = round($saldo);
								$cuota_2 = round((($total * 25)/100 + $total) / 2);
								$cuota_3 = round($total / 3);

								if($producto->nombre == "TJ")
								{
									$producto_nombre = "Tarjeta de Crédito";
								}
								elseif($producto->nombre == "PR")
								{
									$producto_nombre = "Préstamo Personal";
								}
								elseif($producto->nombre == "CC")
								{
									$producto_nombre = "Cuenta corriente";
								}
								else
								{
									$producto_nombre = $producto->nombre;
								}
							?>
							<tr style="border-bottom: 1px solid #6d6e70; font-size: 13px; height: 30px; text-align:center;">
								<th style="text-align:center;"><?php echo $producto_nombre; ?></th>
								<th style="text-align:center;"><?php echo $producto->acreedor; ?></th>
								<th style="text-align:center;"><?php echo $producto->saldo; ?></th>
								<th style="text-align:center;"><?php echo $producto->Cancela; ?></th>
								<th style="text-align:center;"><?php echo $producto->Nctas1; ?></th>
								<th style="text-align:center;"><?php echo $producto->Mcta1; ?></th>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
		<?php endif; ?>

		<?php
		if($_SERVER['REQUEST_METHOD'] == 'POST') {  ?>
			<br /><br />
			<a class="contactorapido_btn" target="_parent" href="http://deudaonline.com.ar/metodos_pago">QUIERO PAGAR</a>
		<?php }  ?>
	</body>
</html>
